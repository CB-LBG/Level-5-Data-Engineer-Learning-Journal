import pyodbc
import json
import os
import logging

# Configure logging
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def connect_to_sql_server(server_name, database_name):
    """
    Establishes a connection to a SQL Server database using Windows authentication.

    Args:
        server_name (str): The name of the SQL Server instance.
        database_name (str): The name of the database.

    Returns:
        pyodbc.Connection: A connection object, or None on error.
    """
    try:
        connection_string = f"Driver={{SQL Server}};Server={server_name};Database={database_name};Trusted_Connection=yes;"
        conn = pyodbc.connect(connection_string)
        print("Successfully connected to SQL Server.")
        return conn
    except Exception as e:
        logging.error(f"Error connecting to SQL Server: {e}")
        return None

def create_table(cursor, table_name, columns):
    """
    Creates a table in the database if it doesn't already exist.

    Args:
        cursor (pyodbc.Cursor): A database cursor object.
        table_name (str): The name of the table to create.
        columns (dict): A dictionary where keys are column names and values are SQL data types.
    """
    try:
        # Check if the table already exists
        if not cursor.tables(table=table_name, tableType='TABLE').fetchone():
            sql_columns = ', '.join(f"[{col_name}] {data_type}" for col_name, data_type in columns.items())
            sql = f"CREATE TABLE [{table_name}] (id INT PRIMARY KEY IDENTITY(1,1), {sql_columns}, JSON_Source VARCHAR(MAX))"
            cursor.execute(sql)
            cursor.commit()
            print(f"Table '{table_name}' created.")
        else:
            print(f"Table '{table_name}' already exists.")
    except Exception as e:
        logging.error(f"Error creating table '{table_name}': {e}")

def insert_data(cursor, table_name, data, source):
    """
    Inserts data into the specified table.

    Args:
        cursor (pyodbc.Cursor): A database cursor object.
        table_name (str): The name of the table to insert data into.
        data (list or dict): The data to insert. If a dict, it's assumed to be a single row.
        source (str): the name of the source file
    """
    try:
        if isinstance(data, dict):
            data = [data]  # Wrap single dict in a list for consistent handling

        if not data:
            print(f"No data to insert into table '{table_name}'.")
            return

        # Get column names from the first data item
        columns = list(data[0].keys())
        placeholders = ", ".join("?" * len(columns))
        column_names = ", ".join(f"[{col}]" for col in columns) #sql format

        # Construct the INSERT statement
        insert_query = f"INSERT INTO {table_name} ({column_names}, JSON_Source) VALUES ({placeholders}, ?)" #added source

        for row in data:
            values = []
            for col in columns:
                value = row.get(col)
                if isinstance(value, dict):
                    value = json.dumps(value)  # Convert dict to JSON string
                elif isinstance(value, list):
                    value = ', '.join(map(str, value))
                values.append(value)
            values.append(source) # Append the source
            try:
                cursor.execute(insert_query, tuple(values)) #changed values to tuple
            except Exception as e:
                logging.error(f"Error inserting row into table '{table_name}': {e}, Data: {values}")
        cursor.commit()
        print(f"{len(data)} rows inserted into table '{table_name}'.")
    except Exception as e:
        logging.error(f"Error inserting data into table '{table_name}': {e}")

def process_json_file(cursor, file_path, server_name, database_name):
    """
    Processes a JSON file, creates a table, and inserts the data into the table.

    Args:
        cursor (pyodbc.Cursor): A database cursor object.
        file_path (str): The path to the JSON file.
        server_name (str): The name of the database.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)

        table_name = os.path.splitext(os.path.basename(file_path))[0]
        source_name = table_name

        # Improved data extraction logic based on file structure
        if table_name == "atm":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("ATM", [])
        elif table_name == "branches":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("Branch", [])
        elif table_name == "business_current_accounts":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("BCA", [])
        elif table_name == "commercial_credit_cards":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("CCC", [])
        elif table_name == "personal_current_accounts":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("PCA", [])
        elif table_name == "unsecured_sme_loans":
            data_to_insert = json_data.get("data", [])[0].get("Brand", [])[0].get("SMELoan", [])
        else:
            logging.error(f"Unsupported file type: {file_path}")
            return

        if not data_to_insert:
            print(f"No data to insert from file '{file_path}'.")
            return

        # Determine columns and their types.
        if isinstance(data_to_insert, list):
            if data_to_insert:
                first_item = data_to_insert[0]
            else:
                logging.error(f"Empty list in file: {file_path}")
                return
        elif isinstance(data_to_insert, dict):
            first_item = data_to_insert
        else:
            logging.error(f"Data is not a list or dict, skipping {file_path}")
            return

        columns = {}
        for key, value in first_item.items():
            if isinstance(value, (int, float)):
                columns[key] = "NUMERIC"
            elif isinstance(value, str):
                columns[key] = "VARCHAR(MAX)"
            elif isinstance(value, list):
                columns[key] = "VARCHAR(MAX)"
            elif isinstance(value, dict):
                columns[key] = "VARCHAR(MAX)"
            else:
                columns[key] = "VARCHAR(MAX)"

        create_table(cursor, table_name, columns)
        insert_data(cursor, table_name, data_to_insert, source_name)

    except json.JSONDecodeError as e:
        logging.error(f"Error decoding JSON in file '{file_path}': {e}")
    except FileNotFoundError:
        logging.error(f"Error: File not found at '{file_path}'")
    except Exception as e:
        logging.error(f"Error processing file '{file_path}': {e}")

def main():
    """
    Main function to connect to SQL Server and process JSON files.
    """
    server_name = "Conor-Desktop"  # Replace with your server name
    database_name = "Lloyds Bank APIs"  # Replace with your database name

    # List of JSON files to process
    json_files = [
        "atm.json",
        "branches.json",
        "business_current_accounts.json",
        "commercial_credit_cards.json",
        "personal_current_accounts.json",
        "unsecured_sme_loans.json"
    ]

    conn = connect_to_sql_server(server_name, database_name)
    if conn:
        cursor = conn.cursor()
        for file_path in json_files:
            process_json_file(cursor, file_path, server_name, database_name)
        cursor.close()
        conn.close()
    else:
        print("Failed to establish a database connection.  Check your server name and database name.")

if __name__ == "__main__":
    main()
