import http.client
import json

conn = http.client.HTTPSConnection("api.lloydsbank.com")
headers = {
    'If-Modified-Since': "REPLACE_THIS_VALUE",
    'If-None-Match': "REPLACE_THIS_VALUE",
    'accept': "application/prs.openbanking.opendata.v2.2+json"
}
conn.request("GET", "/open-banking/v2.2/atms", headers=headers)
res = conn.getresponse()

if res.status == 200:
    data = res.read().decode("utf-8")
    with open('atm.json', 'w') as f:
        json.dump(json.loads(data), f, indent=4)  # Save formatted JSON
    print("Data saved to atm.json")
else:
    print(f"Error: {res.status} {res.reason}")