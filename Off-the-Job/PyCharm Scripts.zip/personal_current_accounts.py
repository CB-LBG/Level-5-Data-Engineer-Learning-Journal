import http.client
import json

conn = http.client.HTTPSConnection("api.lloydsbank.com")
headers = {
    'If-Modified-Since': "REPLACE_THIS_VALUE",
    'If-None-Match': "REPLACE_THIS_VALUE",
    'accept': "application/prs.openbanking.opendata.v2.2+json"
}
conn.request("GET", "/open-banking/v2.2/personal-current-accounts", headers=headers)
res = conn.getresponse()

if res.status == 200:
    data = res.read().decode("utf-8")
    with open('personal_current_accounts.json', 'w') as f:
        json.dump(json.loads(data), f, indent=4)
    print("Data saved to personal_current_accounts.json")
else:
    print(f"Error: {res.status} {res.reason}")